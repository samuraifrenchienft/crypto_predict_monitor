import pytest
import requests
import time
import concurrent.futures
from statistics import mean, median
import psutil
import os

class TestLoadTesting:
    
    @classmethod
    def setup_class(cls):
        """Setup load testing environment"""
        cls.base_url = 'http://localhost:5000'
        cls.results = []
    
    def test_single_user_load(self):
        """Test load from single user making multiple requests"""
        start_time = time.time()
        
        def make_request():
            request_start = time.time()
            response = requests.get(f'{self.base_url}/api/user/test_user/stats')
            request_time = time.time() - request_start
            return {
                'status_code': response.status_code,
                'response_time': request_time,
                'success': response.status_code == 200
            }
        
        # Make 100 requests sequentially
        results = []
        for i in range(100):
            result = make_request()
            results.append(result)
            if i % 10 == 0:
                print(f"Completed {i}/100 requests")
        
        # Analyze results
        successful_requests = [r for r in results if r['success']]
        response_times = [r['response_time'] for r in successful_requests]
        
        assert len(successful_requests) >= 95, f"Too many failed requests: {len(successful_requests)}/100"
        assert mean(response_times) < 1.0, f"Average response time too high: {mean(response_times)}s"
        assert max(response_times) < 5.0, f"Max response time too high: {max(response_times)}s"
        
        print(f"Single user load test passed:")
        print(f"  Success rate: {len(successful_requests)}/100")
        print(f"  Avg response time: {mean(response_times):.3f}s")
        print(f"  Max response time: {max(response_times):.3f}s")
    
    def test_concurrent_users_load(self):
        """Test load from multiple concurrent users"""
        def user_session(user_id):
            """Simulate a user session with multiple requests"""
            session_results = []
            
            # User makes 5 requests
            for i in range(5):
                start_time = time.time()
                response = requests.get(f'{self.base_url}/api/user/{user_id}/stats')
                response_time = time.time() - start_time
                
                session_results.append({
                    'user_id': user_id,
                    'request_num': i,
                    'status_code': response.status_code,
                    'response_time': response_time,
                    'success': response.status_code == 200
                })
                
                # Small delay between requests
                time.sleep(0.1)
            
            return session_results
        
        # Simulate 20 concurrent users
        user_ids = [f'user_{i}' for i in range(20)]
        
        start_time = time.time()
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(user_session, user_id) for user_id in user_ids]
            all_results = []
            for future in concurrent.futures.as_completed(futures):
                all_results.extend(future.result())
        
        total_time = time.time() - start_time
        
        # Analyze results
        successful_requests = [r for r in all_results if r['success']]
        response_times = [r['response_time'] for r in successful_requests]
        
        success_rate = len(successful_requests) / len(all_results)
        avg_response_time = mean(response_times) if response_times else 0
        
        assert success_rate >= 0.95, f"Success rate too low: {success_rate:.2%}"
        assert avg_response_time < 2.0, f"Average response time too high: {avg_response_time:.3f}s"
        
        print(f"Concurrent users load test passed:")
        print(f"  Total requests: {len(all_results)}")
        print(f"  Success rate: {success_rate:.2%}")
        print(f"  Avg response time: {avg_response_time:.3f}s")
        print(f"  Total time: {total_time:.3f}s")
    
    def test_card_generation_load(self):
        """Test load on P&L card generation endpoints"""
        def generate_card(user_id):
            start_time = time.time()
            response = requests.get(f'{self.base_url}/api/pnl-card/{user_id}/share')
            response_time = time.time() - start_time
            
            return {
                'user_id': user_id,
                'status_code': response.status_code,
                'response_time': response_time,
                'success': response.status_code == 200
            }
        
        # Generate cards for 50 users concurrently
        user_ids = [f'card_user_{i}' for i in range(50)]
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(generate_card, user_id) for user_id in user_ids]
            results = [future.result() for future in futures]
        
        successful_requests = [r for r in results if r['success']]
        response_times = [r['response_time'] for r in successful_requests]
        
        assert len(successful_requests) >= 45, f"Too many failed card generations: {len(successful_requests)}/50"
        assert mean(response_times) < 3.0, f"Card generation too slow: {mean(response_times):.3f}s"
        
        print(f"Card generation load test passed:")
        print(f"  Success rate: {len(successful_requests)}/50")
        print(f"  Avg response time: {mean(response_times):.3f}s")
    
    def test_memory_usage(self):
        """Test memory usage during load"""
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Make 1000 requests
        for i in range(1000):
            response = requests.get(f'{self.base_url}/api/health')
            if i % 100 == 0:
                current_memory = process.memory_info().rss / 1024 / 1024
                print(f"Request {i}: Memory usage: {current_memory:.1f}MB")
        
        final_memory = process.memory_info().rss / 1024 / 1024
        memory_increase = final_memory - initial_memory
        
        assert memory_increase < 100, f"Memory increased too much: {memory_increase:.1f}MB"
        
        print(f"Memory usage test passed:")
        print(f"  Initial memory: {initial_memory:.1f}MB")
        print(f"  Final memory: {final_memory:.1f}MB")
        print(f"  Memory increase: {memory_increase:.1f}MB")
