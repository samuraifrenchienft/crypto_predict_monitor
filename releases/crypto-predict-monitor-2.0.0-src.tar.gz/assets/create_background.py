"""
Default Background Generator
Creates cyberpunk-style background for P&L cards
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os
from pathlib import Path

def create_default_background():
    """Create a default cyberpunk background with pure blue theme"""
    
    width, height = 1080, 1350  # Instagram story ratio
    
    # Create base image with dark blue background
    img = Image.new('RGB', (width, height), color=(5, 5, 40))
    draw = ImageDraw.Draw(img)
    
    # Add gradient effect (dark to lighter blue)
    for y in range(height):
        progress = y / height
        r = int(5 + (15 - 5) * progress)
        g = int(5 + (15 - 5) * progress) 
        b = int(40 + (60 - 40) * progress)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    
    # Add grid pattern with blue tint
    for x in range(0, width, 50):
        draw.line([(x, 0), (x, height)], fill=(0, 1, 255, 30), width=1)
    for y in range(0, height, 50):
        draw.line([(0, y), (width, y)], fill=(0, 1, 255, 30), width=1)
    
    # Add diagonal grid for depth
    for i in range(-height, width, 100):
        draw.line([(i, 0), (i + height, height)], fill=(0, 1, 255, 20), width=1)
        draw.line([(i, height), (i + height, 0)], fill=(0, 1, 255, 20), width=1)
    
    # Add glow circles (cyberpunk orbs)
    glow_positions = [
        (200, 300),   # Top left
        (880, 400),   # Top right  
        (540, 800),   # Center
        (300, 1100),  # Bottom left
        (780, 1200)   # Bottom right
    ]
    
    for x, y in glow_positions:
        # Multiple layers for glow effect
        for radius in range(150, 20, -15):
            alpha = max(5, 40 - (radius - 20) // 3)
            draw.ellipse([x-radius, y-radius, x+radius, y+radius], 
                       outline=(0, 1, 255, alpha), width=2)
    
    # Add hexagon pattern (gaming aesthetic)
    import math
    hex_size = 40
    for row in range(0, height // hex_size + 2):
        for col in range(0, width // hex_size + 2):
            x = col * hex_size * 1.5
            y = row * hex_size + (col % 2) * hex_size // 2
            
            # Draw hexagon
            points = []
            for i in range(6):
                angle = math.pi / 3 * i
                px = x + hex_size * math.cos(angle)
                py = y + hex_size * math.sin(angle)
                points.extend([px, py])
            
            draw.polygon(points, outline=(0, 1, 255, 15), width=1)
    
    # Add noise texture for depth
    import random
    for _ in range(5000):
        x = random.randint(0, width)
        y = random.randint(0, height)
        brightness = random.randint(0, 50)
        draw.point([x, y], fill=(brightness, brightness, brightness + 20))
    
    # Add subtle vignette
    for y in range(height):
        for x in range(width):
            # Distance from center
            cx, cy = width // 2, height // 2
            distance = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
            max_distance = math.sqrt(cx ** 2 + cy ** 2)
            
            # Vignette strength
            vignette = max(0, 1 - (distance / max_distance) ** 2)
            
            if vignette < 0.8:
                pixel = img.getpixel((x, y))
                darkened = tuple(int(c * vignette) for c in pixel)
                img.putpixel((x, y), darkened)
    
    # Apply blur for glass effect
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    
    return img

def create_background_with_text():
    """Create background with branding text"""
    
    img = create_default_background()
    draw = ImageDraw.Draw(img)
    
    # Add subtle branding text
    try:
        # Try to load a font
        font_large = ImageFont.truetype("arial.ttf", 120)
        font_small = ImageFont.truetype("arial.ttf", 60)
    except:
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Add "VALHALLA" text (watermark)
    text = "VALHALLA"
    bbox = draw.textbbox((0, 0), text, font=font_large)
    text_width = bbox[2] - bbox[0]
    x = (1080 - text_width) // 2
    y = 1200
    
    # Draw text with glow effect
    for offset in [4, 3, 2, 1]:
        alpha = 20 - offset * 4
        draw.text((x - offset, y - offset), text, fill=(0, 1, 255, alpha), font=font_large)
        draw.text((x + offset, y - offset), text, fill=(0, 1, 255, alpha), font=font_large)
        draw.text((x - offset, y + offset), text, fill=(0, 1, 255, alpha), font=font_large)
        draw.text((x + offset, y + offset), text, fill=(0, 1, 255, alpha), font=font_large)
    
    draw.text((x, y), text, fill=(100, 150, 255, 100), font=font_large)
    
    # Add "CRYPTO PREDICT" subtitle
    subtitle = "CRYPTO PREDICT"
    bbox = draw.textbbox((0, 0), subtitle, font=font_small)
    text_width = bbox[2] - bbox[0]
    x = (1080 - text_width) // 2
    y = 1280
    
    draw.text((x, y), subtitle, fill=(50, 100, 255, 80), font=font_small)
    
    return img

if __name__ == "__main__":
    # Create assets directory if it doesn't exist
    assets_dir = Path("assets")
    assets_dir.mkdir(exist_ok=True)
    
    # Generate background
    print("Creating default background...")
    bg = create_background_with_text()
    
    # Save background
    bg_path = assets_dir / "valhalla_viral_bg.png"
    bg.save(bg_path, "PNG", optimize=True)
    
    print(f"Background saved to: {bg_path}")
    print(f"Dimensions: {bg.size}")
    print(f"File size: {bg_path.stat().st_size / 1024:.1f} KB")
