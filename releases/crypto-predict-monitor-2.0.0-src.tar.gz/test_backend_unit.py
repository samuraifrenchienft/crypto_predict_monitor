import pytest
import json
from unittest.mock import patch, Mock
import requests
from simple_backend import app

class TestBackendUnit:
    
    def setup_method(self):
        """Setup test client"""
        self.app = app.test_client()
        self.app.testing = True
    
    def test_health_endpoint(self):
        """Test basic health endpoint"""
        response = self.app.get('/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
        assert data['service'] == 'Samurai Frenchie P&L Cards'
    
    def test_api_health_endpoint(self):
        """Test API health endpoint"""
        response = self.app.get('/api/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
        assert 'endpoints' in data
    
    def test_markets_endpoint(self):
        """Test markets endpoint"""
        response = self.app.get('/api/markets')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'markets' in data
        assert isinstance(data['markets'], list)
    
    def test_user_stats_success(self):
        """Test user stats endpoint with successful response"""
        response = self.app.get('/api/user/test_user/stats')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['user_id'] == 'test_user'
        assert data['total_trades'] == 2
        assert data['total_pnl'] == 75.50
    
    def test_user_stats_invalid_user(self):
        """Test user stats endpoint with invalid user"""
        response = self.app.get('/api/user/invalid_user/stats')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['user_id'] == 'invalid_user'
        assert data['total_trades'] == 2  # Mock data returns 2 trades for any user
    
    def test_pnl_card_share_success(self):
        """Test P&L card share endpoint"""
        response = self.app.get('/api/pnl-card/test_user/share')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['user_id'] == 'test_user'
        assert 'share_text' in data
        assert 'card_url' in data
    
    def test_pnl_card_download_success(self):
        """Test P&L card download endpoint"""
        response = self.app.get('/api/pnl-card/test_user')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['user_id'] == 'test_user'
        assert 'download_url' in data
        assert data['status'] == 'ready'
