﻿import os; from dotenv import load_dotenv; load_dotenv(); import sys; sys.path.insert(0, os.getcwd()); from src.main_enhanced import main; main()
