import React, { useState, useEffect } from 'react';
import './PnLCard.css';

interface UserStats {
  user_id: string;
  total_trades: number;
  total_pnl: number;
  win_rate: number;
  last_trade?: string;
}

interface CardData {
  user_id: string;
  card_url: string;
  share_text: string;
  timestamp: string;
  stats: {
    total_trades: number;
    total_pnl: number;
    win_rate: number;
  };
}

const PnLCard: React.FC<{ userId?: string }> = ({ userId = 'test_user' }) => {
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [cardData, setCardData] = useState<CardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchUserStats();
    fetchCardData();
  }, [userId]);

  const fetchUserStats = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/user/${userId}/stats`);
      const data = await response.json();
      setUserStats(data);
    } catch (err) {
      setError('Failed to fetch user stats');
    }
  };

  const fetchCardData = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/pnl-card/${userId}/share`);
      const data = await response.json();
      setCardData(data);
    } catch (err) {
      setError('Failed to fetch card data');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    if (cardData?.share_text) {
      if (navigator.share) {
        try {
          await navigator.share({
            title: 'My P&L Card',
            text: cardData.share_text,
            url: cardData.card_url
          });
        } catch (err) {
          console.log('Share cancelled');
        }
      } else {
        navigator.clipboard.writeText(`${cardData.share_text} ${cardData.card_url}`);
        alert('P&L card link copied to clipboard!');
      }
    }
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/pnl-card/${userId}`);
      const data = await response.json();
      
      const link = document.createElement('a');
      link.href = data.download_url;
      link.download = `pnl-card-${userId}.png`;
      link.click();
    } catch (err) {
      setError('Failed to download card');
    }
  };

  if (loading) {
    return <div className="pnl-card loading">Loading P&L data...</div>;
  }

  if (error) {
    return <div className="pnl-card error">{error}</div>;
  }

  return (
    <div className="pnl-card">
      <div className="card-header">
        <h2>📊 P&L Card</h2>
        <span className="user-id">@{userId}</span>
      </div>
      
      <div className="stats-grid">
        <div className="stat-item">
          <div className="stat-value">${userStats?.total_pnl?.toFixed(2) || '0.00'}</div>
          <div className="stat-label">Total P&L</div>
        </div>
        
        <div className="stat-item">
          <div className="stat-value">{userStats?.total_trades || 0}</div>
          <div className="stat-label">Total Trades</div>
        </div>
        
        <div className="stat-item">
          <div className="stat-value">{userStats?.win_rate?.toFixed(1) || '0.0'}%</div>
          <div className="stat-label">Win Rate</div>
        </div>
      </div>

      <div className="card-preview">
        <div className="preview-image">
          <div className="preview-placeholder">
            📈 P&L Card Preview
          </div>
        </div>
      </div>

      <div className="card-actions">
        <button className="btn btn-primary" onClick={handleShare}>
          📤 Share Card
        </button>
        
        <button className="btn btn-secondary" onClick={handleDownload}>
          💾 Download
        </button>
        
        <button className="btn btn-outline" onClick={() => window.open(cardData?.card_url)}>
          🌐 View Online
        </button>
      </div>

      <div className="card-footer">
        <small>
          Generated: {cardData?.timestamp ? new Date(cardData.timestamp).toLocaleString() : 'Unknown'}
        </small>
      </div>
    </div>
  );
};

export default PnLCard;
