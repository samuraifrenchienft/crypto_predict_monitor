import React, { useState } from 'react';
import PnLCard from './components/PnLCard';
import './App.css';

function App() {
  const [userId, setUserId] = useState('test_user');

  return (
    <div className="App">
      <header className="App-header">
        <h1>📊 P&L Card Generator</h1>
        <p>Prediction Market Profit & Loss Cards</p>
      </header>
      
      <main className="App-main">
        <div className="user-selector">
          <label htmlFor="user-select">Select User:</label>
          <select 
            id="user-select" 
            value={userId} 
            onChange={(e) => setUserId(e.target.value)}
          >
            <option value="test_user">Test User</option>
            <option value="demo_user">Demo User</option>
          </select>
        </div>
        
        <PnLCard userId={userId} />
      </main>
      
      <footer className="App-footer">
        <p>Powered By Samurai Frenchie</p>
      </footer>
    </div>
  );
}

export default App;
