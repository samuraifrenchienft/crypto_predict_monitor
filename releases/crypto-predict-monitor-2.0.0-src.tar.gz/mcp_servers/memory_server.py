"""
Memory MCP Server for cloud deployment.
"""

import json
import os
from datetime import datetime
from pathlib import Path

class MemoryMCP:
    def __init__(self):
        self.memory_file = Path("memory.json")
        self.memories = self.load_memories()
    
    def load_memories(self):
        if self.memory_file.exists():
            with open(self.memory_file, 'r') as f:
                return json.load(f)
        return []
    
    def save_memories(self):
        with open(self.memory_file, 'w') as f:
            json.dump(self.memories, f, indent=2)
    
    def create_memory(self, title, content, tags=None):
        memory = {
            "id": len(self.memories) + 1,
            "title": title,
            "content": content,
            "tags": tags or [],
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        self.memories.append(memory)
        self.save_memories()
        return memory
    
    def get_memories(self, tags=None):
        if tags:
            return [m for m in self.memories if any(tag in m.get('tags', []) for tag in tags)]
        return self.memories
    
    def update_memory(self, memory_id, title=None, content=None, tags=None):
        for memory in self.memories:
            if memory["id"] == memory_id:
                if title:
                    memory["title"] = title
                if content:
                    memory["content"] = content
                if tags is not None:
                    memory["tags"] = tags
                memory["updated_at"] = datetime.now().isoformat()
                self.save_memories()
                return memory
        return None
    
    def delete_memory(self, memory_id):
        self.memories = [m for m in self.memories if m["id"] != memory_id]
        self.save_memories()

# Flask app for Memory MCP
from flask import Flask, request, jsonify

app = Flask(__name__)
memory_mcp = MemoryMCP()

@app.route('/memories', methods=['GET'])
def get_memories():
    tags = request.args.getlist('tags')
    return jsonify(memory_mcp.get_memories(tags))

@app.route('/memories', methods=['POST'])
def create_memory():
    data = request.json
    memory = memory_mcp.create_memory(
        title=data.get('title'),
        content=data.get('content'),
        tags=data.get('tags')
    )
    return jsonify(memory)

@app.route('/memories/<int:memory_id>', methods=['PUT'])
def update_memory(memory_id):
    data = request.json
    memory = memory_mcp.update_memory(
        memory_id,
        title=data.get('title'),
        content=data.get('content'),
        tags=data.get('tags')
    )
    if memory:
        return jsonify(memory)
    return jsonify({"error": "Memory not found"}), 404

@app.route('/memories/<int:memory_id>', methods=['DELETE'])
def delete_memory(memory_id):
    memory_mcp.delete_memory(memory_id)
    return jsonify({"success": True})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
