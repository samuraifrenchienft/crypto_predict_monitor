"""
Fetch MCP Server for cloud deployment.
"""

import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/fetch', methods=['POST'])
def fetch_url():
    data = request.json
    url = data.get('url')
    
    if not url:
        return jsonify({"error": "URL is required"}), 400
    
    try:
        response = requests.get(url, timeout=10)
        return jsonify({
            "status_code": response.status_code,
            "content": response.text[:10000],  # Limit to 10k chars
            "headers": dict(response.headers)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
