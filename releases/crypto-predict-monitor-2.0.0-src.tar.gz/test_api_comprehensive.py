import pytest
import json
from simple_backend import app

class TestAPIEndpoints:
    
    def setup_method(self):
        """Setup test client"""
        self.app = app.test_client()
        self.app.testing = True
    
    def test_all_endpoints_respond(self):
        """Test that all endpoints respond with correct status codes"""
        endpoints = [
            ('/health', 200),
            ('/api/health', 200),
            ('/api/markets', 200),
            ('/api/user/test_user/stats', 200),
            ('/api/pnl-card/test_user/share', 200),
            ('/api/pnl-card/test_user', 200)
        ]
        
        for endpoint, expected_status in endpoints:
            response = self.app.get(endpoint)
            assert response.status_code == expected_status, f"Failed for {endpoint}"
    
    def test_response_formats(self):
        """Test that all endpoints return valid JSON"""
        endpoints = [
            '/health', '/api/health', '/api/markets',
            '/api/user/test_user/stats', '/api/pnl-card/test_user/share',
            '/api/pnl-card/test_user'
        ]
        
        for endpoint in endpoints:
            response = self.app.get(endpoint)
            assert response.content_type == 'application/json'
            assert json.loads(response.data)  # Should not raise exception
    
    def test_cors_headers(self):
        """Test CORS headers are present"""
        response = self.app.get('/health')
        assert 'Access-Control-Allow-Origin' in response.headers
    
    def test_invalid_user_id(self):
        """Test endpoints with invalid user IDs"""
        invalid_users = ['', ' ', 'user@invalid', 'user with spaces']
        
        for user_id in invalid_users:
            response = self.app.get(f'/api/user/{user_id}/stats')
            # Should handle gracefully (either 200 with mock data or proper error)
            assert response.status_code in [200, 400, 404]
    
    def test_nonexistent_endpoints(self):
        """Test that non-existent endpoints return 404"""
        response = self.app.get('/api/nonexistent')
        assert response.status_code == 404
