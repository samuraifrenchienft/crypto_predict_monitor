from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if (_ROOT / "src").is_dir() and str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))