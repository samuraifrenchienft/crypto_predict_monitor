import src.config
import src.http_client
import src.logging_setup
import src.main
import src.schemas


def test_imports() -> None:
    assert True