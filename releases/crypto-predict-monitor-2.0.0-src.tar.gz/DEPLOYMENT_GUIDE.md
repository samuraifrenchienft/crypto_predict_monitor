"""
Deployment Guide for P&L Card System
Complete deployment instructions for production
"""

# P&L Card System Deployment Guide

## Overview

This guide covers deploying the complete P&L card system including:
- Backend API with Flask
- Database (Supabase)
- File storage (AWS S3)
- Frontend integration
- Monitoring and logging

## Prerequisites

- Docker and Docker Compose
- Supabase account and project
- AWS account (for S3 storage)
- Discord webhook URL
- Domain name (optional)

## Step 1: Database Setup

### 1.1 Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Note your project URL and keys

### 1.2 Run Database Migrations
```bash
# Set environment variables
export SUPABASE_URL="https://your-project.supabase.co"
export SUPABASE_SERVICE_KEY="your-service-key"

# Run migrations
python -m src.database.migrate
```

### 1.3 Verify Database
```bash
# Test database connection
python -c "
from supabase import create_client
import os
client = create_client(os.getenv('SUPABASE_URL'), os.getenv('SUPABASE_ANON_KEY'))
result = client.table('executions').select('count').execute()
print('Database connected:', result)
"
```

## Step 2: Environment Configuration

### 2.1 Create Environment File
```bash
# Copy production template
cp env.production.template .env

# Edit with your values
nano .env
```

### 2.2 Required Environment Variables
```bash
# Application
ENVIRONMENT=production
SECRET_KEY=your-super-secret-key-here
PORT=5000
FRONTEND_URL=https://yourdomain.com

# Database
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-key

# Discord
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/your-id/your-token
DISCORD_HEALTH_WEBHOOK_URL=https://discord.com/api/webhooks/health-id/health-token

# AWS S3 (optional)
AWS_S3_BUCKET=your-pnl-cards-bucket
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1
```

## Step 3: AWS S3 Setup (Optional)

### 3.1 Create S3 Bucket
```bash
# Using AWS CLI
aws s3 mb s3://your-pnl-cards-bucket --region us-east-1

# Set bucket policy for public access
aws s3api put-bucket-policy --bucket your-pnl-cards-bucket --policy '{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-pnl-cards-bucket/*"
    }
  ]
}'
```

### 3.2 Configure CORS
```bash
aws s3api put-bucket-cors --bucket your-pnl-cards-bucket --cors-configuration '{
  "CORSRules": [
    {
      "AllowedOrigins": ["https://yourdomain.com"],
      "AllowedHeaders": ["*"],
      "AllowedMethods": ["GET", "PUT"],
      "MaxAgeSeconds": 3000
    }
  ]
}'
```

## Step 4: Docker Deployment

### 4.1 Build and Deploy
```bash
# Build Docker image
docker build -t pnl-cards:latest .

# Run with Docker Compose
docker-compose -f docker-compose.yml up -d
```

### 4.2 Docker Compose Production
Create `docker-compose.prod.yml`:
```yaml
version: '3.8'

services:
  app:
    image: pnl-cards:latest
    ports:
      - "5000:5000"
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./assets:/app/assets
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    restart: unless-stopped
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data

volumes:
  redis_data:
```

### 4.3 Deploy
```bash
# Deploy to production
docker-compose -f docker-compose.prod.yml up -d

# Check logs
docker-compose -f docker-compose.prod.yml logs -f app

# Check health
curl http://localhost:5000/health
```

## Step 5: Nginx Reverse Proxy

### 5.1 Nginx Configuration
Create `nginx.conf`:
```nginx
events {
    worker_connections 1024;
}

http {
    upstream app {
        server app:5000;
    }

    server {
        listen 80;
        server_name yourdomain.com;

        # Redirect to HTTPS
        return 301 https://$server_name$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name yourdomain.com;

        # SSL certificates
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;

        # Security headers
        add_header X-Frame-Options DENY;
        add_header X-Content-Type-Options nosniff;
        add_header X-XSS-Protection "1; mode=block";

        # Rate limiting
        limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

        location / {
            proxy_pass http://app;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://app;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
}
```

### 5.2 SSL Setup
```bash
# Use Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

## Step 6: Monitoring and Logging

### 6.1 Log Management
```bash
# Create log directory
mkdir -p logs

# Set up log rotation
sudo nano /etc/logrotate.d/pnl-cards
```

Log rotation config:
```
/path/to/pnl-cards/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 appuser appuser
    postrotate
        docker-compose -f docker-compose.prod.yml restart app
    endscript
}
```

### 6.2 Health Monitoring
Create health check script:
```bash
#!/bin/bash
# health_check.sh

HEALTH_URL="https://yourdomain.com/health"
DISCORD_WEBHOOK="your-discord-health-webhook"

response=$(curl -s -o /dev/null -w "%{http_code}" $HEALTH_URL)

if [ $response != "200" ]; then
    curl -H "Content-Type: application/json" \
         -X POST \
         -d "{\"content\":\"⚠️ P&L Cards health check failed: HTTP $response\"}" \
         $DISCORD_WEBHOOK
fi
```

### 6.3 Cron Job
```bash
# Add to crontab
crontab -e

# Check every 5 minutes
*/5 * * * * /path/to/health_check.sh
```

## Step 7: Frontend Deployment

### 7.1 Build Frontend
```bash
# In your frontend directory
npm run build

# Or with yarn
yarn build
```

### 7.2 Configure API URL
Update your frontend environment:
```bash
# .env.production
REACT_APP_API_URL=https://yourdomain.com
REACT_APP_ENVIRONMENT=production
```

### 7.3 Deploy to Static Hosting
```bash
# Deploy to Netlify, Vercel, or similar
# Or serve with Nginx
sudo cp -r build/* /var/www/html/
```

## Step 8: Testing Production

### 8.1 API Tests
```bash
# Test health endpoint
curl https://yourdomain.com/health

# Test P&L card generation (with auth)
curl -H "Authorization: Bearer your-test-token" \
     https://yourdomain.com/api/pnl-card/test_user/share
```

### 8.2 Integration Tests
```bash
# Run test suite
python -m pytest tests/test_pnl_cards.py -v

# Test with real data
python -c "
import asyncio
from src.social.pnl_card_generator import PnLCardService

async def test():
    service = PnLCardService()
    card_bytes, snapshot = await service.generate_card_bytes('test_user')
    print(f'Generated card: {len(card_bytes)} bytes')

asyncio.run(test())
"
```

## Step 9: Performance Optimization

### 9.1 Redis Caching
```bash
# Check Redis status
docker-compose exec redis redis-cli ping

# Monitor Redis
docker-compose exec redis redis-cli monitor
```

### 9.2 Database Optimization
```sql
-- Add indexes for better performance
CREATE INDEX CONCURRENTLY idx_executions_user_period 
ON executions(user_id, entry_timestamp DESC);

-- Analyze table statistics
ANALYZE executions;
ANALYZE leaderboard;
```

### 9.3 Image Optimization
```bash
# Monitor S3 storage
aws s3 ls s3://your-pnl-cards-bucket --recursive --human-readable --summarize

# Clean up old cards (older than 30 days)
aws s3 ls s3://your-pnl-cards-bucket | \
awk '$1 < "$(date -d '30 days ago' '+%Y-%m-%d')" {print $4}' | \
xargs -I {} aws s3 rm s3://your-pnl-cards-bucket/{}
```

## Step 10: Security Hardening

### 10.1 Firewall Rules
```bash
# UFW setup
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### 10.2 Security Headers
Add to Nginx config:
```nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self';" always;
```

### 10.3 Rate Limiting
```nginx
# Enhanced rate limiting
limit_req_zone $binary_remote_addr zone=strict:10m rate=5r/s;
limit_req_zone $binary_remote_addr zone=moderate:10m rate=20r/s;

location /api/pnl-card/ {
    limit_req zone=strict burst=10 nodelay;
    # ... rest of config
}
```

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check Supabase credentials
   echo $SUPABASE_URL
   echo $SUPABASE_ANON_KEY
   
   # Test connection
   curl -H "apikey: $SUPABASE_ANON_KEY" "$SUPABASE_URL/rest/v1/"
   ```

2. **Card Generation Fails**
   ```bash
   # Check logs
   docker-compose logs app
   
   # Test background image
   ls -la assets/valhalla_viral_bg.png
   ```

3. **S3 Upload Fails**
   ```bash
   # Check AWS credentials
   aws s3 ls
   
   # Test bucket access
   aws s3 ls s3://your-pnl-cards-bucket
   ```

4. **High Memory Usage**
   ```bash
   # Monitor Docker containers
   docker stats
   
   # Restart if needed
   docker-compose restart app
   ```

## Maintenance

### Daily Tasks
- Check health monitoring alerts
- Review error logs
- Monitor S3 storage usage

### Weekly Tasks
- Update security patches
- Rotate secrets if needed
- Backup database

### Monthly Tasks
- Review performance metrics
- Clean up old logs
- Update dependencies

## Support

For issues:
1. Check logs: `docker-compose logs app`
2. Verify environment variables
3. Test database connection
4. Check Discord webhook health

Your P&L card system is now deployed and ready for production! 🚀
